const translations = {
    es: {
        "nav-arch": "Arquitectura",
        "nav-cases": "Casos de Éxito",
        "nav-ind": "Industrias",
        "nav-contact": "Contacto",
        
        "hero-pill": "Tu operación nunca se detiene.",
        "hero-title": "El futuro de tu<br>infraestructura.",
        "hero-btn": "Explorar Soluciones",
        
        "arch-sub": "Arquitectura de Soluciones",
        "arch-title": "Potencia Absoluta.",
        "arch-desc": "Sistemas diseñados con tolerancia a fallos y redundancia extrema para entornos de alto rendimiento.",
        
        "dc-desc": "Diseñamos y construimos cuartos limpios basados en estándares de disponibilidad globales.",
        "dc-1": "• Gabinetes de alta densidad",
        "dc-2": "• Sistemas UPS y PDUs",
        "dc-3": "• Aire de precisión",
        "dc-4": "• Supresión de incendios",
        
        "cyb-title": "Ciberseguridad",
        "cyb-desc": "Firewalls perimetrales, segmentación Zero Trust y protección proactiva contra intrusiones. Seguridad inquebrantable.",
        
        "sys-title": "Sistemas Especiales",
        "sys-desc": "Monitoreo inteligente con analítica de video, control de acceso biométrico y cumplimiento normativo (CTPAT/OEA).",
        
        "stat-1": "Uptime Garantizado en Diseños Tier",
        "stat-2": "Sistemas de IA Desplegados",
        "stat-3": "Monitoreo y Soporte Activo",
        "stat-4": "Cumplimiento Normativo de Seguridad",
        
        "cases-sub": "Casos de Éxito",
        "cases-title": "Proyectos que transforman.",
        
        "case1-title": "Manufactura Inteligente",
        "case1-desc": "Integración de más de 200 cámaras IA para monitoreo automatizado de procesos.",
        
        "case2-title": "Alta Disponibilidad",
        "case2-desc": "Construcción de Data Center con certificación y eficiencia energética optimizada.",
        
        "case3-title": "Redes de Ultra Velocidad",
        "case3-desc": "Implementación de fibra óptica corporativa para conectividad de baja latencia inter-sitios.",
        
        "contact-sub": "Hablemos",
        "contact-title": "El primer paso.",
        "contact-desc": "Contáctanos para una evaluación técnica. Servimos a Manufactura, Logística, Corporativos y Gobierno en toda la región.",
        
        "form-btn": "Enviar Mensaje",
        "support": "Soporte telefónico:",
        "footer": "&copy; 2026 Naitels Inc. Todos los derechos reservados."
    },
    en: {
        "nav-arch": "Architecture",
        "nav-cases": "Success Stories",
        "nav-ind": "Industries",
        "nav-contact": "Contact",
        
        "hero-pill": "Your operation never stops.",
        "hero-title": "The future of your<br>infrastructure.",
        "hero-btn": "Explore Solutions",
        
        "arch-sub": "Solutions Architecture",
        "arch-title": "Absolute Power.",
        "arch-desc": "Systems designed with fault tolerance and extreme redundancy for high-performance environments.",
        
        "dc-desc": "We design and build clean rooms based on global availability standards.",
        "dc-1": "• High-density cabinets",
        "dc-2": "• UPS and PDU systems",
        "dc-3": "• Precision cooling",
        "dc-4": "• Fire suppression",
        
        "cyb-title": "Cybersecurity",
        "cyb-desc": "Perimeter firewalls, Zero Trust segmentation, and proactive intrusion protection. Unbreakable security.",
        
        "sys-title": "Special Systems",
        "sys-desc": "Intelligent monitoring with video analytics, biometric access control, and regulatory compliance (CTPAT/OEA).",
        
        "stat-1": "Guaranteed Uptime in Tier Designs",
        "stat-2": "Deployed AI Systems",
        "stat-3": "Active Monitoring & Support",
        "stat-4": "Security Regulatory Compliance",
        
        "cases-sub": "Success Stories",
        "cases-title": "Projects that transform.",
        
        "case1-title": "Smart Manufacturing",
        "case1-desc": "Integration of over 200 AI cameras for automated process monitoring.",
        
        "case2-title": "High Availability",
        "case2-desc": "Data Center construction with certification and optimized energy efficiency.",
        
        "case3-title": "Ultra-High Speed Networks",
        "case3-desc": "Implementation of corporate fiber optics for low-latency inter-site connectivity.",
        
        "contact-sub": "Let's Talk",
        "contact-title": "The first step.",
        "contact-desc": "Contact us for a technical evaluation. We serve Manufacturing, Logistics, Corporate, and Government across the region.",
        
        "form-btn": "Send Message",
        "support": "Phone Support:",
        "footer": "&copy; 2026 Naitels Inc. All rights reserved."
    }
};

const placeholders = {
    es: {
        "form-name": "Nombre completo",
        "form-email": "Correo electrónico",
        "form-company": "Empresa",
        "form-help": "¿En qué te podemos ayudar?"
    },
    en: {
        "form-name": "Full name",
        "form-email": "Email address",
        "form-company": "Company",
        "form-help": "How can we help you?"
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const langToggleBtn = document.getElementById('lang-toggle');
    const typingContainer = document.getElementById('typing-container');
    
    // Check saved language
    let currentLang = localStorage.getItem('lang') || 'es';
    
    // Initial translation
    setLanguage(currentLang);

    langToggleBtn.addEventListener('click', () => {
        currentLang = currentLang === 'es' ? 'en' : 'es';
        setLanguage(currentLang);
    });

    function setLanguage(lang) {
        localStorage.setItem('lang', lang);
        document.documentElement.lang = lang;
        
        // Update Button Text (Shows the opposite of what's active)
        langToggleBtn.innerText = lang === 'es' ? 'EN' : 'ES';
        
        // Update all text nodes
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (translations[lang][key]) {
                el.innerHTML = translations[lang][key];
            }
        });

        // Update all placeholders
        document.querySelectorAll('[data-i18n-ph]').forEach(el => {
            const key = el.getAttribute('data-i18n-ph');
            if (placeholders[lang][key]) {
                el.setAttribute('placeholder', placeholders[lang][key]);
            }
        });
        
        // Update Typing Text Effect gracefully
        if(typingContainer) {
            const newText = typingContainer.getAttribute(`data-text-\${lang}`);
            const typingSpan = document.querySelector('.typing-text');
            if(typingSpan) {
                // Instantly update the text (the typing animation already ran on load)
                typingSpan.innerText = newText;
            }
        }
    }
});
