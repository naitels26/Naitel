document.addEventListener('DOMContentLoaded', () => {
    // --- THEME TOGGLE LOGIC ---
    const themeToggleBtn = document.getElementById('theme-toggle');
    const rootEl = document.documentElement;
    
    const currentTheme = localStorage.getItem('theme') || 'light';
    if (currentTheme === 'dark') {
        rootEl.setAttribute('data-theme', 'dark');
        updateToggleIcon('dark');
    }

    themeToggleBtn.addEventListener('click', () => {
        let targetTheme = 'light';
        if (rootEl.getAttribute('data-theme') !== 'dark') {
            targetTheme = 'dark';
        }
        
        if (targetTheme === 'dark') {
            rootEl.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
        } else {
            rootEl.removeAttribute('data-theme');
            localStorage.setItem('theme', 'light');
        }
        updateToggleIcon(targetTheme);
    });

    function updateToggleIcon(theme) {
        if (theme === 'dark') {
            themeToggleBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>';
        } else {
            themeToggleBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>';
        }
    }

    // --- STICKY HEADER ---
    const header = document.querySelector('header');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // --- ADVANCED REVEAL ANIMATIONS ---
    const revealElements = document.querySelectorAll('.reveal');
    const revealOptions = {
        threshold: 0.1,
        rootMargin: "0px 0px -50px 0px"
    };
    
    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    }, revealOptions);
    
    revealElements.forEach(el => {
        revealObserver.observe(el);
    });

    // --- MOUSE PARALLAX EFFECT FOR BACKGROUND SHAPES ---
    document.addEventListener("mousemove", parallax);
    function parallax(e) {
        document.querySelectorAll(".shape").forEach(function(move){
            var moving_value = move.getAttribute("data-speed");
            var x = (e.clientX * moving_value) / 100;
            var y = (e.clientY * moving_value) / 100;
            move.style.transform = "translateX(" + x + "px) translateY(" + y + "px)";
        });
    }

    // --- TYPING EFFECT FOR HERO ---
    const typingElement = document.querySelector('.typing-text');
    if (typingElement) {
        const text = typingElement.getAttribute('data-text');
        typingElement.innerHTML = '';
        let i = 0;
        function typeWriter() {
            if (i < text.length) {
                typingElement.innerHTML += text.charAt(i);
                i++;
                setTimeout(typeWriter, 40);
            }
        }
        setTimeout(typeWriter, 1000); // Wait for fade in
    }

    // --- TILT EFFECT FOR BENTO CARDS ---
    const cards = document.querySelectorAll('.glass-card');
    cards.forEach(card => {
        card.addEventListener('mousemove', e => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            card.style.setProperty('--mouse-x', x + 'px');
            card.style.setProperty('--mouse-y', y + 'px');
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            const rotateX = ((y - centerY) / centerY) * -5;
            const rotateY = ((x - centerX) / centerX) * 5;
            
            card.style.transform = "perspective(1000px) rotateX(" + rotateX + "deg) rotateY(" + rotateY + "deg) translateY(-5px) scale(1.02)";
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0) scale(1)';
        });
    });
});

// 1. Preloader Fade Out
window.addEventListener('load', () => {
    const preloader = document.getElementById('preloader');
    if (preloader) {
        setTimeout(() => {
            preloader.style.opacity = '0';
            setTimeout(() => {
                preloader.style.display = 'none';
            }, 500);
        }, 800);
    }
});

// 2. Scroll Progress Bar
const progressBar = document.getElementById('scroll-progress');
window.addEventListener('scroll', () => {
    if (progressBar) {
        const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
        const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrollPercentage = (scrollTop / scrollHeight) * 100;
        progressBar.style.width = scrollPercentage + '%';
    }
});

// 4. Dynamic Stats Counter
const counters = document.querySelectorAll('.counter');
const statsSection = document.getElementById('stats-section');

if (counters.length > 0 && statsSection) {
    let started = false;
    
    const counterObserver = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && !started) {
            started = true;
            counters.forEach(counter => {
                const updateCount = () => {
                    const target = +counter.getAttribute('data-target');
                    const count = +counter.innerText;
                    
                    const inc = target / 50;
                    
                    if (count < target) {
                        if(target % 1 !== 0) {
                            counter.innerText = (count + inc).toFixed(1);
                        } else {
                            counter.innerText = Math.ceil(count + inc);
                        }
                        setTimeout(updateCount, 30);
                    } else {
                        counter.innerText = target;
                    }
                };
                updateCount();
            });
        }
    }, { threshold: 0.5 });
    
    counterObserver.observe(statsSection);
}

// --- LEAFLET INTERACTIVE MAP LOGIC ---
document.addEventListener('DOMContentLoaded', () => {
    const mapElement = document.getElementById('interactive-map');
    if (mapElement && typeof L !== 'undefined') {
        const map = L.map('interactive-map', {
            zoomControl: false,
            scrollWheelZoom: false,
            attributionControl: false
        }).setView([25.0, -102.0], 5);
        
        L.control.zoom({ position: 'topright' }).addTo(map);

        L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; OSM & CARTO',
            subdomains: 'abcd',
            maxZoom: 20
        }).addTo(map);

        const naitelsIcon = L.divIcon({
            className: 'custom-leaflet-icon',
            html: '<div style="background-color: #f26522; width: 14px; height: 14px; border-radius: 50%; border: 2px solid #fff; box-shadow: 0 0 10px rgba(242,101,34,0.8);"></div>',
            iconSize: [14, 14],
            iconAnchor: [7, 7]
        });

        const locations = [
            { name: "Cd Juarez", coords: [31.6904, -106.4245] },
            { name: "Chihuahua", coords: [28.6330, -106.0691] },
            { name: "El Paso, TX", coords: [31.7619, -106.4850] },
            { name: "Monterrey", coords: [25.6866, -100.3161] },
            { name: "San Luis Potosi", coords: [22.1565, -100.9855] },
            { name: "Queretaro", coords: [20.5888, -100.3899] }
        ];

        locations.forEach(loc => {
            L.marker(loc.coords, { icon: naitelsIcon })
             .addTo(map)
             .bindPopup('<strong style="color: #333;">Naitels - ' + loc.name + '</strong>');
        });
        
        setTimeout(() => { map.invalidateSize(); }, 500);
    }
});